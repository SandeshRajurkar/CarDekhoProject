package com.jspiders.cardekho_case_study.entity;

public class Car {
	
	    private int carId;
	    private String carName;
	    private String model;
	    private String brand;
	    private String fuelType;
	    private String price;

	    public Car(int carId, String carName, String model, String brand, String fuelType, String price) {
	        this.carId = carId;
	        this.carName = carName;
	        this.model = model;
	        this.brand = brand;
	        this.fuelType = fuelType;
	        this.price = price;
	    }

	    public int getCarId() {
	        return carId;
	    }

	    public String getCarName() {
	        return carName;
	    }

	    public void setCarName(String carName) {
	        this.carName = carName;
	    }

	    public String getModel() {
	        return model;
	    }

	    public void setModel(String model) {
	        this.model = model;
	    }

	    public String getBrand() {
	        return brand;
	    }

	    public void setBrand(String brand) {
	        this.brand = brand;
	    }

	    public String getFuelType() {
	        return fuelType;
	    }

	    public void setFuelType(String fuelType) {
	        this.fuelType = fuelType;
	    }

	    public String getPrice() {
	        return price;
	    }

	    public void setPrice(String price) {
	        this.price = price;
	    }
	}





