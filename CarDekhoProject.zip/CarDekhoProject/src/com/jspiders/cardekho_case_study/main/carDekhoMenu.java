package com.jspiders.cardekho_case_study.main;
import java.util.Scanner;

import com.jspiders.cardekho_case_study.operation.*;

public class carDekhoMenu {
    public static void main(String[] args) {
        @SuppressWarnings("resource")
		Scanner obj1 = new Scanner(System.in);
        CarOperation carOperation = new CarOperation();

        while (true) {
            System.out.println("======= Car Dekho Menu =======");
            System.out.println("1. Add Car Details");
            System.out.println("2. View Car Details");
            System.out.println("3. Update Car Details");
            System.out.println("4. Delete Car Details");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = obj1.nextInt();
            obj1.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    carOperation.addCarDetails();
                    break;
                case 2:
                    carOperation.viewCarDetails();
                    break;
                case 3:
                    carOperation.updateCarDetails();
                    break;
                case 4:
                    carOperation.deleteCarDetails();
                    break;
                case 5:
                    System.out.println("Thank you for visiting!");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}


