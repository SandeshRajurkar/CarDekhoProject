package com.jspiders.cardekho_case_study.operation;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.jspiders.cardekho_case_study.entity.Car;


public class CarOperation {
    private List<Car> carList;
	private Scanner scanner;
	private Scanner scanner2;

    public CarOperation() {
        carList = new ArrayList<>();
    }

    public void addCarDetails() {
        scanner = new Scanner(System.in);

        System.out.println("======= Add Car Details =======");
        System.out.print("Enter car Id: ");
        int carId = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        System.out.print("Enter car name: ");
        String carName = scanner.nextLine();

        System.out.print("Enter car model: ");
        String model = scanner.nextLine();

        System.out.print("Enter car brand: ");
        String brand = scanner.nextLine();

        System.out.print("Enter fuel type: ");
        String fuelType = scanner.nextLine();

        System.out.print("Enter car price: ");
        String price = scanner.nextLine();

        Car car = new Car(carId, carName, model, brand, fuelType, price);
        carList.add(car);

        System.out.println("Car details added successfully!");
    }

    public void updateCarDetails() {
        scanner2 = new Scanner(System.in);
        

        System.out.println("======= Update Car Details =======");
        System.out.print("Enter car Id: ");
        int carId = scanner2.nextInt();
        scanner2.nextLine(); // Consume the newline character

        boolean found = false;
        for (Car car : carList) {
            if (car.getCarId() == carId) {
                System.out.print("Enter new car name: ");
                car.setCarName(scanner2.nextLine());

                System.out.print("Enter new car model: ");
                car.setModel(scanner2.nextLine());

                System.out.print("Enter new car brand: ");
                car.setBrand(scanner2.nextLine());

                System.out.print("Enter new fuel type: ");
                car.setFuelType(scanner2.nextLine());

                System.out.print("Enter new car price: ");
                car.setPrice(scanner2.nextLine());

                found = true;
                break;
            }
        }

        System.out.println(found ? "Car details updated successfully!" : "Car not found. Update failed.");
    }

    public void viewCarDetails() {
        System.out.println("======= View Car Details =======");

        if (carList.isEmpty()) {
            System.out.println("No cars available.");
            return;
        }else {

        for (Car car : carList) {
            System.out.println("Car Id: " + car.getCarId());
            System.out.println("Car Name: " + car.getCarName());
            System.out.println("Car Model: " + car.getModel());
            System.out.println("Car Brand: " + car.getBrand());
            System.out.println("Fuel Type: " + car.getFuelType());
            System.out.println("Car Price: " + car.getPrice());
            System.out.println("--------------------");
        }
    }
    }
        


    public void deleteCarDetails() {
        try (Scanner obj1 = new Scanner(System.in)){
			System.out.println("======= Delete Car Details =======");
			System.out.print("Enter car Id: ");
			int carId = obj1.nextInt();
			obj1.nextLine(); // Consume the newline character

			boolean removed = false;
			for (Car car : carList) {
			    if (car.getCarId() == carId) {
			        carList.remove(car);
			        removed = true;
			        break;
			    }
			}

			System.out.println(removed ? "Car details deleted successfully!" : "Car not found. Deletion failed.");
		
		}
        
    }
}
